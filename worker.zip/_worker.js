import { connect } from 'cloudflare:sockets';
let userID = 'd342d11e-d424-4583-b36e-524ab1f0afa4';
let proxyIP = '';
const WS_READY_STATE_OPEN = 1;
const WS_READY_STATE_CLOSING = 2;
export default {
  async fetch(request, env, ctx) {
    userID = env.UUID || userID;
    proxyIP = env.PROXYIP || proxyIP;   
    try {
      if(request.headers.get('Upgrade') === 'websocket') {
        return await ressOverWSHandler(request);
      }
      const url = new URL(request.url);
      const routes = new Map([
        ['/', () => new Response(JSON.stringify(request.cf))],
        [`/${userID}`, () => {
          const config = getConfig(userID, request.headers.get('Host'));
          return new Response(config, {
            headers: {'Content-Type': 'text/plain;charset=utf-8'}
          });
        }]
      ]);
      const handler = routes.get(url.pathname);
      return handler ? handler() : new Response('Not found', {status: 404});
    } catch (err) {
      return new Response(err.toString());
    }
  }
};
async function ressOverWSHandler(request) {
    const webSocketPair = new WebSocketPair();
    const [client, webSocket] = Object.values(webSocketPair);
    webSocket.accept();
    let address = '';
    const earlyHeader = request.headers.get('sec-websocket-protocol') || '';
    const readableWebStream = makeWebStream(webSocket, earlyHeader);
    let remoteSocket = { value: null };
    let udpWrite = null;
    let isDns = false;
    readableWebStream.pipeTo(new WritableStream({
        async write(chunk, controller) {
            if (isDns && udpWrite) {
                return udpWrite(chunk);
            }
            if (remoteSocket.value) {
                const writer = remoteSocket.value.writable.getWriter();
                await writer.write(chunk);
                writer.releaseLock();
                return;
            }
            const {
                hasError,
                portRemote = 443,
                addressRemote = '',
                rawDataIndex,
                ressVersion = new Uint8Array([0, 0]),
                isUDP,
            } = processRessHeader(chunk, userID);
            address = addressRemote;
            if (hasError) {
                return;
            }
            if (isUDP) {
                if (portRemote === 53) {
                    isDns = true;
                } else {
                    return;
                }
            }
            const resHeader = new Uint8Array([ressVersion[0], 0]);
            const clientData = chunk.slice(rawDataIndex);
            if (isDns) {
                const { write } = await handleUDPOutBound(webSocket, resHeader);
                udpWrite = write;
                udpWrite(clientData);
                return;
            }
            handleTCPOutBound(remoteSocket, addressRemote, portRemote, clientData, webSocket, resHeader);
        },
    })).catch((err) => {
        closeWebSocket(webSocket);
    });
    return new Response(null, {
        status: 101,
        webSocket: client,
    });
}
async function handleTCPOutBound(remoteSocket, addressRemote, portRemote, clientData, webSocket, resHeader) {
    async function connectAndWrite(address, port) {
        if (!remoteSocket.value || remoteSocket.value.closed) {
            remoteSocket.value = connect({ hostname: address, port });
        }
        const writer = remoteSocket.value.writable.getWriter();
        await writer.write(clientData);
        writer.releaseLock();
        return remoteSocket.value;
    }
    async function tryConnect(address, port) {
        const tcpSocket = await connectAndWrite(address, port);
        return forwardToData(tcpSocket, webSocket, resHeader);
    }
    try {
        if (!(await tryConnect(addressRemote, portRemote)) && !(await tryConnect(proxyIP, portRemote))) {
            closeWebSocket(webSocket);
        }
    } catch (error) {
        closeWebSocket(webSocket);
    }
}
function makeWebStream(webSocket, earlyHeader) {
    let isCancel = false;
    const stream = new ReadableStream({
        start(controller) {
            webSocket.addEventListener('message', (event) => {
                if (isCancel) return;
                const message = event.data;
                controller.enqueue(message);
            });
            webSocket.addEventListener('close', () => {
                closeWebSocket(webSocket);
                if (isCancel) return;
                controller.close();
            });
            webSocket.addEventListener('error', (err) => {
                controller.error(err);
            });
            const { earlyData, error } = base64ToBuffer(earlyHeader);
            if (error) {
                controller.error(error);
            } else if (earlyData) {
                controller.enqueue(earlyData);
            }
        },
        pull(controller) {
        },
        cancel(reason) {
            if (isCancel) return;
            isCancel = true;
            closeWebSocket(webSocket);
        }
    });
    return stream;
}
let cachedUserID;
const ADDRESS_TYPES = {
    IPV4: 1,
    DOMAIN: 2,
    IPV6: 3
};
function processRessHeader(ressBuffer, userID) {
    if (ressBuffer.byteLength < 24) {
        return { hasError: true };
    }
    const dataView = new DataView(ressBuffer.buffer);
    const version = new Uint8Array(ressBuffer.slice(0, 1));
    let isUDP = false;
    if (!cachedUserID) {
        cachedUserID = new Uint8Array(
            userID.replace(/-/g, '')
                 .match(/[0-9a-f]{2}/g)
                 .map(byte => parseInt(byte, 16))
        );
    }
    const bufferUserID = new Uint8Array(ressBuffer.slice(1, 17));
    const hasError = bufferUserID.some((byte, index) => byte !== cachedUserID[index]);
    if (hasError) {
        return { hasError: true };
    }
    const optLength = new Uint8Array(ressBuffer.slice(17, 18))[0];
    const command = new Uint8Array(ressBuffer.slice(18 + optLength, 18 + optLength + 1))[0];
    if (command === 2) {
        isUDP = true;
    } else if (command !== 1) {
        return { hasError: false };
    }
    const portIndex = 18 + optLength + 1;
    const portRemote = dataView.getUint16(portIndex);
    let addressIndex = portIndex + 2;
    const addressType = new Uint8Array(ressBuffer.slice(addressIndex, addressIndex + 1))[0];
    let addressLength = 0;
    let addressValueIndex = addressIndex + 1;
    let addressValue = '';
    switch (addressType) {
        case ADDRESS_TYPES.IPV4:
            addressLength = 4;
            addressValue = new Uint8Array(
                ressBuffer.slice(addressValueIndex, addressValueIndex + addressLength)
            ).join('.');
            break;
        case ADDRESS_TYPES.DOMAIN:
            addressLength = new Uint8Array(ressBuffer.slice(addressValueIndex, addressValueIndex + 1))[0];
            addressValueIndex += 1;
            addressValue = new TextDecoder().decode(
                ressBuffer.slice(addressValueIndex, addressValueIndex + addressLength)
            );
            break;
        case ADDRESS_TYPES.IPV6:
            addressLength = 16;
            const ipv6Data = new DataView(
                ressBuffer.slice(addressValueIndex, addressValueIndex + addressLength)
            );
            const ipv6Parts = new Array(8).fill(0)
                .map((_, i) => ipv6Data.getUint16(i * 2).toString(16))
                .map(part => part.padStart(4, '0'));
            addressValue = ipv6Parts.join(':');
            break;
        default:
            return { hasError: true };
    }
    if (!addressValue) {
        return { hasError: true };
    }
    return {
        hasError: false,
        addressRemote: addressValue,
        addressType,
        portRemote,
        rawDataIndex: addressValueIndex + addressLength,
        ressVersion: version,
        isUDP,
    };
}
async function forwardToData(remoteSocket, webSocket, resHeader) {
    let hasData = false;
    const BUFFER_SIZE = 131072;
    try {
        await remoteSocket.readable.pipeTo(new WritableStream({
            async write(chunk, controller) {
                let bufferToSend;               
                if (resHeader) {
                    bufferToSend = new Uint8Array(resHeader.byteLength + chunk.byteLength);
                    bufferToSend.set(resHeader, 0);
                    bufferToSend.set(chunk, resHeader.byteLength);
                    resHeader = null;
                } else {
                    bufferToSend = chunk;
                }
                for (let offset = 0; offset < bufferToSend.length; offset += BUFFER_SIZE) {
                    const slice = bufferToSend.slice(offset, offset + BUFFER_SIZE);                   
                    if (webSocket.readyState === WS_READY_STATE_OPEN) {
                        webSocket.send(slice);
                        hasData = true;
                    } else {
                        controller.error(new Error('WebSocket closed'));
                    }
                }
            },
        }));
    } catch (error) {
        closeWebSocket(webSocket);
    }
    return hasData;
}
function base64ToBuffer(base64Str) {
    if (!base64Str) {
        return { error: null };
    }
    try {
        const normalizedStr = base64Str.replace(/-/g, '+').replace(/_/g, '/');
        const binaryStr = atob(normalizedStr);
        const length = binaryStr.length;
        const arrayBuffer = new Uint8Array(length);
        for (let i = 0; i < length; i++) {
            arrayBuffer[i] = binaryStr.charCodeAt(i);
        }
        return { earlyData: arrayBuffer.buffer, error: null };
    } catch (error) {
        return { error };
    }
}
function closeWebSocket(socket) {
    if (socket.readyState === WS_READY_STATE_OPEN || socket.readyState === WS_READY_STATE_CLOSING) {
        socket.close();
    }
}
async function handleUDPOutBound(webSocket, resHeader) {
    const CHUNK_SIZE = 16384;
    let headerSent = false;
    let partialChunk = null;    
    const transformStream = new TransformStream({
        transform(chunk, controller) {
            if (partialChunk) {
                chunk = new Uint8Array([...partialChunk, ...chunk]);
                partialChunk = null;
            }            
            let offset = 0;
            while (offset < chunk.byteLength) {
                if (chunk.byteLength < offset + 2) {
                    partialChunk = chunk.slice(offset);
                    break;
                }
                const dataView = new DataView(chunk.buffer, chunk.byteOffset + offset);
                const udpPacketLength = dataView.getUint16(0);
                const nextOffset = offset + 2 + udpPacketLength;
                if (chunk.byteLength < nextOffset) {
                    partialChunk = chunk.slice(offset);
                    break;
                }
                const udpData = chunk.slice(offset + 2, nextOffset);
                offset = nextOffset;               
                controller.enqueue(udpData);
            }
        }
    });
    transformStream.readable.pipeTo(new WritableStream({
        async write(chunk) {
            try {
                const response = await fetch('https://cloudflare-dns.com/dns-query', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/dns-message',
                        'Accept': 'application/dns-message'
                    },
                    body: chunk
                });
                if (!response.ok) {
                    throw new Error(`DNS query failed: ${response.status}`);
                }
                const dnsQueryResult = await response.arrayBuffer();
                const udpSizeBuffer = new Uint8Array([
                    (dnsQueryResult.byteLength >> 8) & 0xff,
                    dnsQueryResult.byteLength & 0xff
                ]);
                const payload = headerSent 
                    ? new Uint8Array([...udpSizeBuffer, ...new Uint8Array(dnsQueryResult)])
                    : new Uint8Array([...resHeader, ...udpSizeBuffer, ...new Uint8Array(dnsQueryResult)]);               
                headerSent = true;
                if (webSocket.readyState === WS_READY_STATE_OPEN) {
                    webSocket.send(payload);
                }
            } catch (error) {
                closeWebSocket(webSocket);
            }
        }
    })).catch(error => {
        closeWebSocket(webSocket);
    });
    const writer = transformStream.writable.getWriter();
    return {
        write(chunk) {
            for (let i = 0; i < chunk.length; i += CHUNK_SIZE) {
                const slice = chunk.slice(i, Math.min(i + CHUNK_SIZE, chunk.length));
                writer.write(slice).catch(error => {
                    closeWebSocket(webSocket);
                });
            }
        }
    };
}
function getConfig(userID, hostName) {
    return `vless://${userID}\u0040${hostName}:443?encryption=none&security=tls&sni=${hostName}&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560#${hostName}`;
}
